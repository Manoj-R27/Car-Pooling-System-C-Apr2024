 #include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "header.h"

void saveToFile(const char *filename, struct vehicle *vehicles, int numvehicles, struct trip *trips, int numtrips, struct commuter *commuters, int numcommuters, struct feedback *feedbacks, int num_feedbacks) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Failed to open file for writing.\n");
        return;
    }

    for (int i = 0; i < numvehicles; i++) {
        fprintf(file, "vehicle,%s,%s,%s\n", vehicles[i].make, vehicles[i].model, vehicles[i].numberplate);
    }

    for (int i = 0; i < numtrips; i++) {
        fprintf(file, "trip,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d\n",
                trips[i].startlocation, trips[i].endlocation, trips[i].date, trips[i].time, trips[i].status,
                trips[i].vehicle_make, trips[i].vehicle_model, trips[i].vehicle_available, trips[i].request_status, trips[i].numCommuters);
        for (int j = 0; j < trips[i].numCommuters; j++) {
            fprintf(file, "commuter,%s\n", trips[i].commuters[j]->name);
        }
    }

    for (int i = 0; i < numcommuters; i++) {
        fprintf(file, "commuter,%s,%s,%d,%.2f,%s\n",
                commuters[i].name, commuters[i].email, commuters[i].mobile, commuters[i].amount_due, commuters[i].payment_status);
    }

    for (int i = 0; i < num_feedbacks; i++) {
        fprintf(file, "feedback,%s,%s\n", feedbacks[i].commenter_name, feedbacks[i].comment);
    }

    fclose(file);
}

int isFutureDate(const char *date);

int main() {
    struct vehicle *vehicles = NULL;
    int numvehicles = 0;
    struct trip *trips = NULL;
    int numtrips = 0;
    struct commuter *commuters = NULL;
    int numcommuters = 0;
    struct feedback *feedbacks = NULL;
    int num_feedbacks = 0;

    vehicles = (struct vehicle *)malloc(sizeof(struct vehicle));
    trips = (struct trip *)malloc(sizeof(struct trip));
    commuters = (struct commuter *)malloc(sizeof(struct commuter));
    feedbacks = (struct feedback *)malloc(sizeof(struct feedback));
    int choice;
    if (vehicles == NULL || trips == NULL || commuters == NULL || feedbacks == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1;
    }

    do {
        printf("\nMenu:\n");
        printf("1. Add Vehicle\n");
        printf("2. Delete Vehicle\n");
        printf("3. Add Trip\n");
        printf("4. View Requests\n");
        printf("5. Approve Request\n");
        printf("6. Reject Request\n");
        printf("7. View Past Trips\n");
        printf("8. Form Temporary Groups\n");
        printf("9. Calculate Cost\n");
        printf("10. View Payment Status\n");
        printf("11. Search Vehicles\n");
        printf("12. Send Request\n");
        printf("13. View Upcoming Trips\n");
        printf("14. Make Payment\n");
        printf("15. View Vehicle Availability\n");
        printf("16. Give Feedback\n");
        printf("17. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

       
        switch (choice) {
            case 1:
                addvehicle(&vehicles, &numvehicles);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 2:
                deletevehicle(&vehicles, &numvehicles);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 3:
                addtrip(&trips, &numtrips);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 4:
                viewrequests(trips, numtrips);
                break;
            case 5:
                approverequest(trips, numtrips);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 6:
                rejectrequest(trips, numtrips);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 7:
                viewpasttrips(trips, numtrips);
                break;
            case 8:
                formtempgroups(vehicles, numvehicles, trips, numtrips, commuters, numcommuters);
                break;
            case 9:
                calculatecost(trips, numtrips);
                break;
            case 10:
                viewpaymentstatus(commuters, numcommuters);
                break;
            case 11:
                searchvehicles(vehicles, numvehicles);
                break;
            case 12:
                sendrequest(trips, numtrips, commuters, numcommuters);
                break;
            case 13:
                viewupcomingtrips(trips, numtrips);
                break;
            case 14:
                makepayment(commuters, numcommuters);
                break;
            case 15:
                viewvehicleavailability(trips, numtrips);
                break;
            case 16:
                givefeedback(&feedbacks, &num_feedbacks);
                saveToFile("data.txt", vehicles, numvehicles, trips, numtrips, commuters, numcommuters, feedbacks, num_feedbacks);
                break;
            case 17:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice. Please enter a number between 1 and 17.\n");
        }
    } while (choice != 17);

    free(vehicles);
    vehicles = NULL;

    free(trips);
    trips = NULL;

    free(commuters);
    commuters = NULL;

    free(feedbacks);
    feedbacks = NULL;

    return 0;
}


void addvehicle(struct vehicle **vehicles, int *numvehicles) {
    (*numvehicles)++;
    *vehicles = realloc(*vehicles, sizeof(struct vehicle) * (*numvehicles));
    if (*vehicles == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        exit(1);
    }

    printf("Enter vehicle details:\n");
    printf("Make: ");
    scanf("%s", (*vehicles)[*numvehicles - 1].make);
    printf("Model: ");
    scanf("%s", (*vehicles)[*numvehicles - 1].model);
    printf("Number Plate: ");
    scanf("%s", (*vehicles)[*numvehicles - 1].numberplate);

    
    FILE *file = fopen("vehicles.txt", "a");
    if (file == NULL) {
        printf("Failed to open file for writing.\n");
        return;
    }

    fprintf(file, "Make:%s\nModel:%s\nNumber Plate:%s\n", (*vehicles)[*numvehicles - 1].make, (*vehicles)[*numvehicles - 1].model, (*vehicles)[*numvehicles - 1].numberplate);

 
    fclose(file);

    printf("Vehicle added and written to file.\n");
}


void deletevehicle(struct vehicle **vehicles, int *numvehicles) {
    char plateToDelete[20];
    printf("Enter the number plate of the vehicle to delete: ");
    scanf("%s", plateToDelete);

    int found = 0;
    for (int i = 0; i < *numvehicles; i++) {
        if (strcmp((*vehicles)[i].numberplate, plateToDelete) == 0) {
            found = 1;
            for (int j = i; j < *numvehicles - 1; j++) {
                (*vehicles)[j] = (*vehicles)[j + 1];
            }
            (*numvehicles)--;
            break;
        }
    }

    if (found) {
        printf("Vehicle with number plate %s deleted.\n", plateToDelete);

        FILE *file = fopen("vehicles.txt", "w");
        if (file == NULL) {
            printf("Failed to open file for writing.\n");
            return;
        }

        for (int i = 0; i < *numvehicles; i++) {
            fprintf(file, "%s,%s,%s\n", (*vehicles)[i].make, (*vehicles)[i].model, (*vehicles)[i].numberplate);
        }
        fclose(file);
    } else {
        printf("Vehicle with number plate %s not found.\n", plateToDelete);
    }
}
void loadvehicles(struct vehicle **vehicles, int *numvehicles) {
    FILE *file = fopen("vehicles.txt", "r");
    if (file == NULL) {
        printf("No existing vehicles file found. Starting with an empty list.\n");
        return;
    }

    char line[100];
    while (fgets(line, sizeof(line), file)) {
        (*numvehicles)++;
        *vehicles = realloc(*vehicles, sizeof(struct vehicle) * (*numvehicles));
        if (*vehicles == NULL) {
            printf("Memory allocation failed. Exiting...\n");
            exit(1);
        }

        sscanf(line, "%[^,],%[^,],%s", (*vehicles)[*numvehicles - 1].make, (*vehicles)[*numvehicles - 1].model, (*vehicles)[*numvehicles - 1].numberplate);
    }
    fclose(file);
}

void addtrip(struct trip **trips, int *numtrips) {
    (*numtrips)++;
    *trips = realloc(*trips, sizeof(struct trip) * (*numtrips));
    if (*trips == NULL) {
        printf("Memory allocation failed. Unable to add trip.\n");
        return;
    }

    struct trip *new_trip = &(*trips)[*numtrips - 1];
    new_trip->numCommuters = 0;
    new_trip->commuters = NULL;

    printf("Enter start location of the trip: ");
    while (getchar() != '\n');  
    scanf("%99s", new_trip->startlocation);

    printf("Enter end location of the trip: ");
    while (getchar() != '\n');  
    scanf("%99s", new_trip->endlocation);

    printf("Enter date of the trip (YYYY-MM-DD): ");
    while (getchar() != '\n');  
    scanf("%9s", new_trip->date);

    printf("Enter time of the trip: ");
    while (getchar() != '\n');  
    scanf("%4s", new_trip->time);

    printf("Enter kilometers of the trip: ");
    while (getchar() != '\n');  
    scanf("%lf", &new_trip->kilometers);

    new_trip->numCommuters = 0;
    new_trip->commuters = NULL;

    strcpy(new_trip->status, "request");

    printf("Trip added successfully.\n");

    FILE *file = fopen("trips.txt", "a");
    if (file == NULL) {
        printf("Failed to open file for writing.\n");
        return;
    }
   
    fprintf(file, "%s,%s,%s,%s,%s,%lf\n", new_trip->startlocation, new_trip->endlocation,
            new_trip->date, new_trip->time, new_trip->status, new_trip->kilometers);
    fclose(file);
}

void viewrequests(struct trip *trips, int numtrips) {
    FILE *file = fopen("trips.txt", "r");
    if (file == NULL) {
        printf("Failed to open file for reading.\n");
        return;
    }

    int found = 0;
    char startlocation[100], endlocation[100], date[20], time[20], status[20];
    while (fscanf(file, "%[^,],%[^,],%[^,],%[^,],%s\n", startlocation, endlocation, date, time, status) != EOF) {
        if (strcmp(status, "request") == 0) {
            printf("Trip: %s to %s on %s at %s\n", startlocation, endlocation, date, time);
            found = 1;
        }
    }

    fclose(file);

    if (!found) {
        printf("No trip requests found.\n");
    }
}

void approverequest(struct trip *trips, int numtrips) {
    int tripIndex;
    printf("Enter the index of the trip to approve: ");
    scanf("%d", &tripIndex);
    
    if (tripIndex >= 1 && tripIndex <= numtrips && strcmp(trips[tripIndex - 1].status, "request") == 0) {
        strcpy(trips[tripIndex - 1].status, "approved");
        printf("Trip %d approved.\n", tripIndex);

        FILE *file = fopen("trips.txt", "r+");
        if (file == NULL) {
            printf("Failed to open file for reading and writing.\n");
            return;
        }

        fseek(file, (tripIndex - 1) * sizeof(struct trip), SEEK_SET);
        
      
        fprintf(file, "%s,%s,%s,%s,%s\n", trips[tripIndex - 1].startlocation, trips[tripIndex - 1].endlocation,
                trips[tripIndex - 1].date, trips[tripIndex - 1].time, trips[tripIndex - 1].status);

        fclose(file);
    } else {
        printf("Invalid trip index or trip is not in 'request' status.\n");
    }
}

void rejectrequest(struct trip *trips, int numtrips) {
    char response[10];
    printf("Enter the trip number to reject: ");
    int trip_number;
    scanf("%d", &trip_number);
    if (trip_number < 1 || trip_number > numtrips) {
        printf("Invalid trip number.\n");
        return;
    }

    printf("Are you sure you want to reject this trip? (yes/no): ");
    scanf("%s", response);
    if (strcmp(response, "yes") == 0) {
        strcpy(trips[trip_number - 1].status, "rejected");
        printf("Trip %d rejected successfully.\n", trip_number);

        
        FILE *file = fopen("trips.txt", "r+");
        if (file == NULL) {
            printf("Failed to open file for reading and writing.\n");
            return;
        }

        struct trip *fileTrips = malloc(sizeof(struct trip) * numtrips);
        if (fileTrips == NULL) {
            printf("Memory allocation failed.\n");
            fclose(file);
            return;
        }
        fread(fileTrips, sizeof(struct trip), numtrips, file);

        strcpy(fileTrips[trip_number - 1].status, "rejected");

        fseek(file, 0, SEEK_SET); 
        fwrite(fileTrips, sizeof(struct trip), numtrips, file);

      
        free(fileTrips);

        fclose(file);
    } else {
        printf("Rejection canceled.\n");
    }
}


void viewpasttrips(struct trip *trips, int numtrips) {

    FILE *file = fopen("trips.txt", "r");
    

    int found = 0;
    for (int i = 0; i < numtrips; i++) {
    
        struct trip currentTrip;
        fread(&currentTrip, sizeof(struct trip), 1, file);

        if (isFutureDate(currentTrip.date) == 0) {
            printf("Trip %d: %s to %s on %s at %s\n", i + 1, currentTrip.startlocation, currentTrip.endlocation, currentTrip.date, currentTrip.time);
            found = 1;
        }
    }
    if (!found) {
        printf("No past trips found.\n");
    }

  
    fclose(file);
}


void formtempgroups(struct vehicle *vehicles, int numvehicles, struct trip *trips, int numtrips, struct commuter *commuters, int numcommuters) {
    FILE *file = fopen("temp_groups.txt", "a");
    

    fprintf(file, "Temporary Groups:\n");

    fprintf(file, "Available Vehicles:\n");
    for (int i = 0; i < numvehicles; i++) {
        fprintf(file, "Vehicle %d: %s %s\n", i + 1, vehicles[i].make, vehicles[i].model);
    }
    fprintf(file, "\n");

    fprintf(file, "Available Trips:\n");
    for (int i = 0; i < numtrips; i++) {
        fprintf(file, "Trip %d: %s to %s\n", i + 1, trips[i].startlocation, trips[i].endlocation);
    }
    fprintf(file, "\n");

    fprintf(file, "Commuters forming groups:\n");
    for (int i = 0; i < numcommuters; i++) {
        fprintf(file, "Commuter %d (%s):\n", i + 1, commuters[i].name);

        int vehicle_choice;
        fprintf(file, "Select a vehicle (1-%d): ", numvehicles);
        scanf("%d", &vehicle_choice);
        if (vehicle_choice < 1 || vehicle_choice > numvehicles) {
            fprintf(file, "Invalid vehicle choice.\n");
            continue;
        }
        char permission;
        fprintf(file, "Does the owner give permission to join this group? (y/n): ");
        scanf(" %c", &permission);
        if (permission != 'y' && permission != 'Y') {
            fprintf(file, "Owner did not give permission to join this group.\n");
            continue;
        }

        int trip_choice;
        fprintf(file, "Select a trip (1-%d): ", numtrips);
        scanf("%d", &trip_choice);
        if (trip_choice < 1 || trip_choice > numtrips) {
            fprintf(file, "Invalid trip choice.\n");
            continue;
        }

        fprintf(file, "Chosen vehicle: %s %s\n", vehicles[vehicle_choice - 1].make, vehicles[vehicle_choice - 1].model);
        fprintf(file, "Chosen trip: %s to %s\n", trips[trip_choice - 1].startlocation, trips[trip_choice - 1].endlocation);

        fprintf(file, "Commuter added to the group.\n");
        fprintf(file, "\n");

        
        if (trips[trip_choice - 1].numCommuters < 10) {
            trips[trip_choice - 1].commuters[trips[trip_choice - 1].numCommuters] = &commuters[i];
            trips[trip_choice - 1].numCommuters++;
        } else {
            fprintf(file, "Maximum number of commuters reached for this trip.\n");
        }
    }

    fclose(file);
}


void calculatecost(struct trip *trips, int numtrips) {
    FILE *file = fopen("costs.txt", "a");
    
    fprintf(file, "Cost for the trip:\n");

    double fuel_cost_per_unit = 2.5; 
    double fuel_consumption_rate = 0.15; 
    double cost_per_km = 0.10; 

    for (int i = 0; i < numtrips; i++) {
        double distance = trips[i].kilometers; 
        double fuel_consumed = fuel_consumption_rate * distance;
        double fuel_cost = fuel_consumed * fuel_cost_per_unit;
        double total_cost = cost_per_km * distance;

        fprintf(file, "Trip %d: %.2f units of fuel consumed, Fuel Cost: $%.2f, Total Cost: $%.2f\n", i + 1, fuel_consumed, fuel_cost, total_cost);
    }

    fclose(file);
}


void viewpaymentstatus(struct commuter *commuters, int numcommuters) {
    FILE *file = fopen("payment_status.txt", "w");
    
    fprintf(file, "Payment Status:\n");
    for (int i = 0; i < numcommuters; i++) {
        fprintf(file, "Commuter %d: %s - Payment Status: %s\n", i + 1, commuters[i].name, commuters[i].payment_status);
    }

    fclose(file);
}


void searchvehicles(struct vehicle *vehicles, int numvehicles) {
    FILE *file = fopen("search_results.txt", "w");
   

    int found = 0;
    char search_plate[20];
    printf("Enter vehicle number plate to search: ");
    scanf("%s", search_plate);

    fprintf(file, "Search Results for Vehicle with Number Plate \"%s\":\n", search_plate);
    for (int i = 0; i < numvehicles; i++) {
        if (strcmp(vehicles[i].numberplate, search_plate) == 0) {
            printf("Vehicle found: Make: %s, Model: %s, Number Plate: %s\n", vehicles[i].make, vehicles[i].model, vehicles[i].numberplate);
            fprintf(file, "Vehicle found: Make: %s, Model: %s, Number Plate: %s\n", vehicles[i].make, vehicles[i].model, vehicles[i].numberplate);
            found = 1;
            break;  
        }
    }

    if (!found) {
        printf("No vehicle found with number plate \"%s\".\n", search_plate);
        fprintf(file, "No vehicle found with number plate \"%s\".\n", search_plate);
    }

    fclose(file);
}



void sendrequest(struct trip *trips, int numtrips, struct commuter *commuters, int numcommuters) {
    FILE *file = fopen("requests.txt", "a");
   

    int trip_number;
    fprintf(file, "Available Trips:\n");
    for (int i = 0; i < numtrips; i++) {
        fprintf(file, "Trip %d: %s to %s\n", i + 1, trips[i].startlocation, trips[i].endlocation);
    }

    printf("Enter the trip number to send request: ");
    scanf("%d", &trip_number);
    if (trip_number < 1 || trip_number > numtrips) {
        printf("Invalid trip number.\n");
        fclose(file);
        return;
    }

    fprintf(file, "Request sent for trip %d: %s to %s\n", trip_number, trips[trip_number - 1].startlocation, trips[trip_number - 1].endlocation);

    strcpy(trips[trip_number - 1].request_status, "Pending");

    commuters->requested_trip = &trips[trip_number - 1];

    fclose(file);

}
void viewupcomingtrips(struct trip *trips, int numtrips) {
    FILE *file = fopen("trips.txt", "r");
   

    fprintf(file, "Upcoming Trips:\n");
    int upcoming_trip_count = 0;
    for (int i = 0; i < numtrips; i++) {
        if (isFutureDate(trips[i].date) && (strcmp(trips[i].status, "request") == 0 || strcmp(trips[i].status, "approved") == 0)) {
            fprintf(file, "Trip %d:\n", i + 1);
            fprintf(file, "Start Location: %s\n", trips[i].startlocation);
            fprintf(file, "End Location: %s\n", trips[i].endlocation);
            fprintf(file, "Date: %s\n", trips[i].date);
            fprintf(file, "Time: %s\n", trips[i].time);
            fprintf(file, "\n");
            upcoming_trip_count++;
        }
    }
    if (upcoming_trip_count == 0) {
        fprintf(file, "No upcoming trips found.\n");
    }

    fclose(file);
}

int isFutureDate(const char *date) {
    struct tm given_time = {0};
    time_t current_time = time(NULL);
    struct tm *current_local_time = localtime(&current_time);

    int year, month, day;
    FILE *file = fopen("date.txt", "r");
  
    fscanf(file, "%d-%d-%d", &year, &month, &day);
    fclose(file);

    given_time.tm_year = year - 1900;
    given_time.tm_mon = month - 1;
    given_time.tm_mday = day;

    if (mktime(&given_time) > mktime(current_local_time)) {
        return 1;
    } else {
        return 0;
    }
}


void makepayment(struct commuter *commuters, int numcommuters) {
    int commuter_index;
    double payment_amount;

    printf("Enter your name: ");
    char name[50];
    scanf("%s", name);

    FILE *file = fopen("trips.txt", "r+");
  

    for (int i = 0; i < numcommuters; i++) {
        if (strcmp(commuters[i].name, name) == 0) {
            commuter_index = i;
            break;
        }
    }

    if (strcmp(commuters[commuter_index].name, name) != 0) {
        printf("Commuter not found.\n");
        fclose(file);
        return;
    }

    printf("Amount due: $%.2f\n", commuters[commuter_index].amount_due);
    printf("Enter payment amount: $");
    scanf("%lf", &payment_amount);

    if (payment_amount <= 0) {
        printf("Invalid payment amount.\n");
        fclose(file);
        return;
    }

    commuters[commuter_index].amount_due -= payment_amount;
    if (commuters[commuter_index].amount_due <= 0) {
        strcpy(commuters[commuter_index].payment_status, "Paid");
    }

    fseek(file, commuter_index * sizeof(struct commuter), SEEK_SET);
    fwrite(&commuters[commuter_index], sizeof(struct commuter), 1, file);

    printf("Payment successful. Remaining amount due: $%.2f\n", commuters[commuter_index].amount_due);

    fclose(file);
}

void viewvehicleavailability(struct trip *trips, int numtrips) {
    FILE *file = fopen("vehicles.txt", "r");
   

    printf("Vehicle availability:\n");
    for (int i = 0; i < numtrips; i++) {
        char availability[20];
        fscanf(file, "%s", availability);
        printf("Trip %d: %s to %s - Vehicle: %s %s - Availability: %s\n", i + 1, trips[i].startlocation, trips[i].endlocation, trips[i].vehicle_make, trips[i].vehicle_model, availability);
    }

    fclose(file);
}


void givefeedback(struct feedback **feedbacks, int *num_feedbacks) {
    (*num_feedbacks)++;
    *feedbacks = realloc(*feedbacks, sizeof(struct feedback) * (*num_feedbacks));
   
    printf("Enter your name: ");
    scanf("%s", (*feedbacks)[*num_feedbacks - 1].commenter_name);

    printf("Enter your feedback (max 1000 characters):\n");
    scanf(" %[^\n]", (*feedbacks)[*num_feedbacks - 1].comment);

    FILE *file = fopen("feedbacks.txt", "a");
   -
    fprintf(file, "Name: %s\nFeedback: %s\n\n", (*feedbacks)[*num_feedbacks - 1].commenter_name, (*feedbacks)[*num_feedbacks - 1].comment);

    fclose(file);

    printf("Thank you for your feedback!\n");
}