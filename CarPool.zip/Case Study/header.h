#ifndef HEADER_H
#define HEADER_H

struct trip;

struct vehicle
{
    char make[50];
    char model[50];
    char numberplate[20];
    char ownername[100];
};

struct commuter
{
    char name[50];
    char email[100];
    int mobile;
    double amount_due;
    char payment_status[20];
    struct trip *requested_trip; 
};

struct trip
{
    char startlocation[100];
    char endlocation[100];
    char date[20];
    char time[20];
    char status[20]; 
    double kilometers;
    char vehicle_make[50]; 
    char vehicle_model[50]; 
    int vehicle_available;
    char request_status[20];
    struct commuter **-commuters; 
    int numCommuters; 
};

struct feedback {
    char commenter_name[50];
    char comment[1000];
};

void addvehicle(struct vehicle **vehicles,int *numvehicles);
void deletevehicle(struct vehicle **vehicles,int *numvehicles);
void addtrip(struct trip **trips,int *numtrips);
void viewrequests(struct trip *trips,int numtrips);
void approverequest(struct trip *trips,int numtrips);
void rejectrequest(struct trip *trips,int numtrips);
void viewpasttrips(struct trip *trips,int numtrips);
void formtempgroups(struct vehicle *vehicles, int numvehicles, struct trip *trips, int numtrips, struct commuter *commuters, int numcommuters);
void calculatecost(struct trip *trips, int numtrips);
void viewpaymentstatus(struct commuter *commuters, int numcommuters);
void searchvehicles(struct vehicle *vehicles, int numvehicles);
void sendrequest(struct trip *trips, int numtrips, struct commuter *commuters, int numcommuters);
void makepayment(struct commuter *commuters, int numcommuters);
void viewupcomingtrips(struct trip *trips, int numtrips);
void viewvehicleavailability(struct trip *trips, int numtrips);
void givefeedback(struct feedback **feedbacks, int *num_feedbacks);

#endif
